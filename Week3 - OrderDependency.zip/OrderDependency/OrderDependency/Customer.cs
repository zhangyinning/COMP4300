﻿
namespace OrderDependency
{
    internal class Customer
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }

        public Customer(string customerId, string customerName)
        {
            CustomerId = customerId;
            CustomerName = customerName;
        }
    }
}
