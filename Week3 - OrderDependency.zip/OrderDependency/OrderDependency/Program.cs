﻿namespace OrderDependency
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer1 = new Customer("123456", "Yinning Zhang");

            Order order1 = new Order(00001, customer1, DateTime.Now);

            order1.PrintOrder();
        }
    }
}