﻿
namespace OrderDependency
{
    internal class Order
    {
        public int OrderId { get; set; }
        private  string OrderCustomerId { get; set; }

        private string OrderCustomerName { get; set; }
        public DateTime OrderDateTime { get; set; }

        public Order(int orderId, Customer customer, DateTime time)
        {
            this.OrderCustomerId = customer.CustomerId;
            this.OrderCustomerName = customer.CustomerName;
            this.OrderId = orderId;
            this.OrderDateTime = time;
        }

        public void PrintOrder()
        {
            Console.WriteLine($"{this.OrderCustomerName} has placed an order.");
        }


    }
}
