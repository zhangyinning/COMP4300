﻿
namespace LibraryAggregation
{
    internal class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }

        public Book(string title, string author)
        {
            this.Title = title;
            this.Author = author;
        }

        public void PrintBook()
        {
            Console.WriteLine($"{this.Title} written by {this.Author}");
        }
    }
}
