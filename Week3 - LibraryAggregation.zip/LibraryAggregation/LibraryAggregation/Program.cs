﻿namespace LibraryAggregation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> librBooks = new List<Book>();
            librBooks.Add(new Book("Huckleberry", "Mark Twain"));
            librBooks.Add(new Book("Little House", "Laura Ingalls Wilder"));

            Library carrolltonLib = new Library("Carrollton Library", librBooks);
            carrolltonLib.DisplayBooks();
        }
    }
}