﻿
namespace LibraryAggregation
{
    internal class Library
    {
        private List<Book> books;
        public string LibName { get; set; }

        public Library(string name, List<Book> books)
        {
            this.books = books;
            this.LibName = name;
        }

        public void DisplayBooks()
        {
            Console.WriteLine($"{this.LibName} has the following books:");
            foreach (Book a in this.books)
            {
                a.PrintBook();
            }
        }
    }
}
