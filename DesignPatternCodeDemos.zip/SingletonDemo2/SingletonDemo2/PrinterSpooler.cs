﻿namespace SingletonDemo2
{
    /// <summary>
    /// Singleton Class
    /// </summary>
    internal class PrinterSpooler
    {
        /// <summary>
        /// a private instance of the class
        /// </summary>
        private static PrinterSpooler? _spooler;

        /// <summary>
        /// a property to add printers to the spooler
        /// </summary>
        private readonly List<Printer> _printers = new List<Printer>();

        /// <summary>
        /// Indexes to rotate the printers
        /// </summary>
        private int _nextPrinter = 0;
        private Printer? _currentPrinter;


        /// <summary>
        /// private constructor
        /// </summary>
        private PrinterSpooler()
        {
            _printers.Add(new Printer("Printer1"));
            _printers.Add(new Printer("Printer2"));
            _printers.Add(new Printer("Printer3"));
        }

        /// <summary>
        /// Get instances
        /// </summary>
        /// <returns></returns>
        public static PrinterSpooler GetPrinterSpooler()
        {
            if (_spooler == null)
            {
                _spooler = new PrinterSpooler();
            }
            return _spooler;
        }

        /// <summary>
        /// Rotate the printers
        /// </summary>
        /// <returns></returns>
        public Printer AssignNext()
        {
            _currentPrinter = _printers[_nextPrinter];
            Console.WriteLine(_currentPrinter.Name);
            _nextPrinter++;
            if (_nextPrinter > 2)
            {
                _nextPrinter = 0;
            }
            return _currentPrinter;
        }

    }
}
