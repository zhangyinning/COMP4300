﻿namespace SingletonDemo2
{

    /// <summary>
    /// Printer class
    /// </summary>
    internal class Printer
    {
        public string Name { get; set; }

        public Printer(string name)
        {
            this.Name = name;
        }
    }
}
