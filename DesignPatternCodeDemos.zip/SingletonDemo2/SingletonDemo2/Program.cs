﻿namespace SingletonDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PrinterSpooler mySpooler = PrinterSpooler.GetPrinterSpooler();
            PrinterSpooler mySpooler2 = PrinterSpooler.GetPrinterSpooler();

            for (int i = 0; i < 15; i++)
            {
                mySpooler.AssignNext();
                mySpooler2.AssignNext();
            }
        }
    }
}   