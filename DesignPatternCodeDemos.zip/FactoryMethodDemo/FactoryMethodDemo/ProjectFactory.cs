﻿namespace FactoryMethodDemo
{
    /// <summary>
    /// The abstract creator class
    /// </summary>
    internal abstract class ProjectFactory
    {
        public List<IDeveloper> Developers { get; } = new List<IDeveloper>();

        public ProjectFactory()
        {
            // ReSharper disable once VirtualMemberCallInConstructor
            AddDevelopers();
        }

        /// <summary>
        /// abstract factory method.
        /// </summary>
        public abstract void AddDevelopers();
    }

    /// <summary>
    /// Concrete CreatorA
    /// </summary>
    /// <seealso cref="FactoryMethodDemo.ProjectFactory" />
    class TypeAProject : ProjectFactory
    {
        public override void AddDevelopers()
        {
            Developers.Add(new FrontEndDeveloper());
            Developers.Add(new BackEndDeveloper());
        }
    }

    /// <summary>
    /// Concrete CreatorB
    /// </summary>
    /// <seealso cref="FactoryMethodDemo.ProjectFactory" />
    class TypeBProject : ProjectFactory
    {
        public override void AddDevelopers()
        {
            Developers.Add(new FrontEndDeveloper());
            Developers.Add(new TestingPro());
        }
    }
}
