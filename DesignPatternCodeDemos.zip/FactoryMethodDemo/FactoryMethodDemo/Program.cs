﻿namespace FactoryMethodDemo
{
    internal class Program
    {
        /// <summary>Defines the entry point of the application.</summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {

            List<ProjectFactory> projects = new List<ProjectFactory>();
            projects.Add(new TypeAProject());
            projects.Add(new TypeBProject());

            foreach (ProjectFactory project in projects)
            {
                Console.WriteLine(project.GetType());
                foreach (IDeveloper developer in project.Developers)
                {
                    developer.DoWork();
                }
            }
        }
    }
}
