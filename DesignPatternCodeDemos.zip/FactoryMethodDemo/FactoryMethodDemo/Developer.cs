﻿namespace FactoryMethodDemo
{

    /// <summary>
    /// abstract product
    /// </summary>
    internal interface IDeveloper
    {
        public void DoWork();

    }

    /// <summary>
    /// Concrete productA
    /// </summary>
    /// <seealso cref="FactoryMethodDemo.IDeveloper" />
    internal class FrontEndDeveloper : IDeveloper
    {
        public void DoWork()
        {
            Console.WriteLine("I write javascript.");
        }
    }

    /// <summary>
    /// Concrete ProductB
    /// </summary>
    /// <seealso cref="FactoryMethodDemo.IDeveloper" />
    internal class BackEndDeveloper : IDeveloper
    {
        public void DoWork()
        {
            Console.WriteLine("Hi. I write java.");
        }
    }

    internal class TestingPro:IDeveloper
    {
        public void DoWork()
        {
            Console.WriteLine("Hi. I do unit testing.");
        }
    }
}
