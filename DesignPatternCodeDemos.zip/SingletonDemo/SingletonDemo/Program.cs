﻿namespace SingletonDemo
{
    /// <summary>
    ///   main method
    /// </summary>
    internal class Program
    {
        static void Main()
        {
            Printer.GetInstance();
            Printer.GetInstance();
        }
    }
}