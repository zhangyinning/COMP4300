﻿namespace SingletonDemo
{
    internal class Printer
    {
        private Printer() { }

        private static Printer? _instance;

        /// <summary>Gets the instance.</summary>
        /// <returns>
        ///   a unique instance of the Printer Class
        /// </returns>
        public static Printer GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Printer();
                Console.WriteLine("This is a new instance.");

            }
            else
            {
                Console.WriteLine("Existing instance was created.");
            }
            return _instance;
        }

    }
}
