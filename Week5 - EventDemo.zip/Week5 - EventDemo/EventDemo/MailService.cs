﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    internal class MailService
    {
        public void SendEmail(object source, VideoEncodeEventArgs args)
        {
            Console.WriteLine($"Email sent. Time used : {args.ElapsedTime}");
        }
    }
}
