﻿
namespace EventDemo
{
    internal class Video
    {
        public string Title { get; set; }

        public Video(string title)
        {
            Title = title;
        }
    }
}
