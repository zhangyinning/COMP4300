﻿namespace EventDemo
{
    public class VideoEncodeEventArgs : EventArgs
    {
        public TimeSpan ElapsedTime { get; set; }
    }
    internal class Encoder
    {
        
        
        public delegate void VideoEncodedEventHandler(Object source, VideoEncodeEventArgs args);
        public event VideoEncodedEventHandler VideoEncoded;
        public void Encode(Video video)
        {
            Console.WriteLine("Encoded the video.");

            OnVideoEncoded(new VideoEncodeEventArgs{ElapsedTime = new TimeSpan(2)});
        }

        protected virtual void OnVideoEncoded(VideoEncodeEventArgs e)
        {
            if (VideoEncoded != null)
            {
                VideoEncoded(this, e);
            }

        }
    }
}
