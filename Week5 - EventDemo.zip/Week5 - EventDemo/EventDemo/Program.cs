﻿namespace EventDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Video myVideo = new Video("Yinning's video");
            Encoder encoder = new Encoder();
            MailService mailService = new MailService();

            encoder.VideoEncoded += mailService.SendEmail;
            

            encoder.Encode(myVideo);

        }
    }
}